<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://themeforest.net/user/kamleshyadav
 * @since      1.0.0
 *
 * @package    Miraculous_El
 * @subpackage Miraculous_El/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
