<?php if(!defined('FW')) {
    die( 'Forbidden' );
}
$options = array(
     'messages'   => array(
        'label'   => __('Enter Your Message', 'miraculous'),
        'type'    => 'textarea'
      ),
    );			
 