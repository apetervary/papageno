<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Artists Profile', 'miraculous'),
        'description'   => __('Artists Profile', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-user',
        'popup_size'    => 'small',
    )
);
?>  