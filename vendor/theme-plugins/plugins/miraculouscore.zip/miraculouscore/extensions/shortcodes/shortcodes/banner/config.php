<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Banner', 'miraculous'),
        'description'   => __('Add Banner', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-address-card',
        'popup_size'    => 'small', 
    )
);
?>