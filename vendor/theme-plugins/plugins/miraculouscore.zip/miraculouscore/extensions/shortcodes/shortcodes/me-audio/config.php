<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Artist Audio', 'miraculous'),
        'description'   => __('Artist Audio', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-headphones',
        'popup_size'    => 'small', 
    )
);
?>