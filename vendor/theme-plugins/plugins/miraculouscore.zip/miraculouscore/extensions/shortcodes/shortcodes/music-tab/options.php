<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'tab_lable'   => array(
        'label'   => __('Tab Heading', 'miraculous'),
        'type'    => 'text'
    ),
    'music_number' => array(
        'label'   => __('Number of Songs', 'miraculous'),
        'type'    => 'text'
        ),
);
?>