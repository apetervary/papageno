<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Upload WC Products', 'miraculous'),
        'description'   => __('Upload WC Products', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-cart-arrow-down',
        'popup_size'    => 'small',
    )
);
?> 