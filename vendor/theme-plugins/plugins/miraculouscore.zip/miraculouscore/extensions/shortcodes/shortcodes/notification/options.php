<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'notify_label'   => array(
        'label'   => __('Label', 'miraculous'),
        'type'    => 'text'
    ),
    'notify_number' => array(
        'label'   => __('Number of Songs', 'miraculous'),
        'type'    => 'text'
    )
);