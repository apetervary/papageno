<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Bulk Upload', 'miraculous'),
        'description'   => __('Import Form Excel File', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-film',
        'popup_size'    => 'small', // can be large, medium or small
    )
);
?>