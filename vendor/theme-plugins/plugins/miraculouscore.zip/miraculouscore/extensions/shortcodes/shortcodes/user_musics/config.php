<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Users Purchased Tracks', 'miraculous'),
        'description'   => __('Users Purchased Tracks', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-music',
        'popup_size'    => 'small', 
    )
);
?>