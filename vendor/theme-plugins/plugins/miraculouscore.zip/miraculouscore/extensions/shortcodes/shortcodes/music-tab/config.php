<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Music Tab', 'miraculous'),
        'description'   => __('Music Tab', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-user-circle',
        'popup_size'    => 'small',
       )
    );
?>