<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'user_playlist_heading'   => array(
        'label'   => __('Heading', 'miraculous'),
        'type'    => 'text'
    ),
);
?>