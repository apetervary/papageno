<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('About Settings', 'miraculous'),
        'description'   => __('About Settings', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-user-plus',
        'popup_size'    => 'small', 
    )
);
?>