<?php if (!defined('FW')) die('Forbidden');
    $options = array(
        'albums_label'   => array(
            'label'   => __('Label', 'miraculous'),
            'help'    => __('help', 'miraculous'),
            'type'    => 'text'
            ),
        'album_number'   => array(
            'label'   => __('Show Number Of Album', 'miraculous'),
            'help'    => __('help', 'miraculous'),
            'type'    => 'text'
           ),
        );
?>