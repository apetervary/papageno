<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Artist Products', 'miraculous'),
        'description'   => __('Artist Products', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-cart-arrow-down',
        'popup_size'    => 'small', 
    )
);
?> 