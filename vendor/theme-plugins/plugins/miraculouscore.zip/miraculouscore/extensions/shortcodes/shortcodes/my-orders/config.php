<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('My Orders', 'miraculous'),
        'description'   => __('My Orders', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-headphones',
        'popup_size'    => 'small', 
    )
);
?>