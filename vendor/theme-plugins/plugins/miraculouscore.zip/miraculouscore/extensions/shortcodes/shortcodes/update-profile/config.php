<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Update Profile', 'miraculous'),
        'description'   => __('Update Profile', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-user-plus',
        'popup_size'    => 'small', 
    )
);
?>