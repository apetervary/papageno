<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('View Profile', 'miraculous'),
        'description'   => __('View Profile', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-user',
        'popup_size'    => 'small', 
    )
);
?>