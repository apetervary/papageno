<?php if ( ! defined( 'FW' ) ):
	die( 'Forbidden' );
endif;

$options = array(
	'rev_alias' => array(
        'type'  => 'text',        
        'label' => __('Enter Revslider alias name', 'miraculous'),
     ), 
);  
