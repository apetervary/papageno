<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Logout', 'miraculous'),
        'description'   => __('Add Logout', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-pencil-square-o',
        'popup_size'    => 'small', // can be large, medium or small
    )
);
?>