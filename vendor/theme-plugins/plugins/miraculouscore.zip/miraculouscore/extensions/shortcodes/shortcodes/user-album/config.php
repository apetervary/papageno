<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('User Album', 'miraculous'),
        'description'   => __('Add me Album', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-microphone',
        'popup_size'    => 'small', // can be large, medium or small
    )
);
?>