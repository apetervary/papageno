<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Radio', 'miraculous'),
        'description'   => __('Add Radio', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-lastfm',
        'popup_size'    => 'small',
    )
);
?>