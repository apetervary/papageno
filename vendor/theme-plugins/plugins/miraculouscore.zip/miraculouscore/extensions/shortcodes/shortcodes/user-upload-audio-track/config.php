<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('User Upload Audio Track', 'miraculous'),
        'description'   => __('User Uploaded Tracks', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-headphones',
        'popup_size'    => 'small', 
    )
);
?>