<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Albums', 'miraculous'),
        'description'   => __('Add Albums', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-film',
        'popup_size'    => 'small', // can be large, medium or small
    )
);
?>