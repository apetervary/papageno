<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'about_heading'   => array(
        'label'   => __('About Heading', 'miraculous'),
        'type'    => 'text'
    ),
);
?>