<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Update Album', 'miraculous'),
        'description'   => __('Update Album', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-align-left',
        'popup_size'    => 'small',
    )
);
?>  