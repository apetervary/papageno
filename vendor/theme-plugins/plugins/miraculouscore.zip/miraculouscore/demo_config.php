<?php
// Disable regenerating images while importing media
add_filter( 'pt-ocdi/regenerate_thumbnails_in_content_import', '__return_false' );
add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );

// Change some options for the jQuery modal window
function miraculous_ocdi_confirmation_dialog_options ( $options ) {
    return array_merge( $options, array(
        'width'       => 400,
        'dialogClass' => 'wp-dialog',
        'resizable'   => false,
        'height'      => 'auto',
        'modal'       => true,
    ) );
}
add_filter( 'pt-ocdi/confirmation_dialog_options', 'miraculous_ocdi_confirmation_dialog_options', 10, 1 );


// OneClick Demo Importer
add_filter( 'pt-ocdi/import_files', 'miraculous_import_files' );
function miraculous_import_files() {
    return array (

        array(
            'import_file_name'             => esc_html__( 'Darkversion', 'miraculous' ),
            'import_preview_image_url'     => plugin_dir_url( __FILE__ ) .'demos/Darkversion/screen-image.png',
            'import_file_url'              => plugin_dir_url( __FILE__ ) .'demos/Darkversion/content.xml',
            'import_widget_file_url'       => plugin_dir_url( __FILE__ ) .'demos/Darkversion/widgets.json',
            'import_notice'                => __( 'All other pages will not imported with this Homepage.', 'miraculous' ),
            'preview_url'                  => 'https://kamleshyadav.com/templatemonster/watchstore/',
            'import_redux'                 => array (
                array(
                    'file_url'   => plugin_dir_url( __FILE__ ) .'demos/Darkversion/settings.json',
                    'option_name' => 'miraculous_options',
                ),
            ),
        ),
        array(
            'import_file_name'             => esc_html__( 'Lightversion', 'miraculous' ),
            'import_preview_image_url'     => plugin_dir_url( __FILE__ ) .'demos/Lightversion/screen-image.jpg',
            'import_file_url'              => plugin_dir_url( __FILE__ ) .'demos/Lightversion/content.xml',
            'import_widget_file_url'       => plugin_dir_url( __FILE__ ) .'demos/Lightversion/widgets.json',
            'import_notice'                => __( 'All other pages will not imported with this Homepage.', 'miraculous' ),
            'preview_url'                  => 'https://kamleshyadav.com/templatemonster/watchstore/',
            'import_redux'                 => array (
                array(
                    'file_url'   => plugin_dir_url( __FILE__ ) .'demos/Lightversion/settings.json',
                    'option_name' => 'miraculous_options',
                ),
            ),
        ),
        array(
            'import_file_name'             => esc_html__( 'Verion3', 'miraculous' ),
            'import_preview_image_url'     => plugin_dir_url( __FILE__ ) .'demos/Verion3/screen-image.jpg',
            'import_file_url'              => plugin_dir_url( __FILE__ ) .'demos/Verion3/content.xml',
            'import_widget_file_url'       => plugin_dir_url( __FILE__ ) .'demos/Verion3/widgets.json',
            'import_notice'                => __( 'All other pages will not imported with this Homepage.', 'miraculous' ),
            'preview_url'                  => 'https://kamleshyadav.com/templatemonster/watchstore/',
            'import_redux'                 => array (
                array(
                    'file_url'   => plugin_dir_url( __FILE__ ) .'demos/Verion3/settings.json',
                    'option_name' => 'miraculous_options',
                ),
            ),
        ),
    );
}


function miraculous_after_import_setup($selected_import) {
    /**
     * Import The Sliders
     */
     
    $slider = new RevSlider();
    $slider->importSliderFromPost( true, true,  plugin_dir_path( __FILE__ ) .'demos/Darkversion/homeslider.zip' );
    
    if ( class_exists( 'RevSlider' ) ) {
        if ( 'Lightversion' == $selected_import['import_file_name'] ) {
            $slider = new RevSlider();
            $slider->importSliderFromPost( true, true,  plugin_dir_path( __FILE__ ) .'demos/Lightversion/homeslider.zip' );
        }
    }
    
    // Assign menus to their locations.
    $menu_one = get_term_by('name', 'Menu-one', 'nav_menu' );
	$menu_two = get_term_by( 'name', 'Menu-two', 'nav_menu' );
	$menu_three = get_term_by( 'name', 'Menu-three', 'nav_menu' );
	$artist = get_term_by( 'name', 'Artist Menu', 'nav_menu' );
	$listener = get_term_by( 'name', 'Listener Menu', 'nav_menu' );
	if ( isset( $menu_one->term_id ) ) {
		set_theme_mod( 'nav_menu_locations', array(
				'menu_one' => $menu_one->term_id,
				'menu_middle' => $menu_two->term_id,
				'menu_last' => $menu_three->term_id,
				'artist' => $artist->term_id,
				'listener' => $listener->term_id,
			)
		); 
	}

    // Disable Elementor's Default Colors and Default Fonts
    update_option( 'elementor_disable_color_schemes', 'yes' );
    update_option( 'elementor_disable_typography_schemes', 'yes' );
    update_option( 'elementor_global_image_lightbox', '' );

    // Assign front page and posts page (blog page).
    if ( 'Darkversion' == $selected_import['import_file_name'] ) {
        $front_page_id = get_page_by_title( 'discover' );
    }
    if ( 'Lightversion' == $selected_import['import_file_name'] ) {
        $front_page_id = get_page_by_title( 'discover' );
    }
    if ( 'Verion3' == $selected_import['import_file_name'] ) {
        $front_page_id = get_page_by_title( 'discover' );
    }

    $blog_page_id  = get_page_by_title( 'Blog' );
    // Set the home page and blog page
    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    update_option( 'page_for_posts', $blog_page_id->ID );

}
add_action( 'pt-ocdi/after_import', 'miraculous_after_import_setup', 10, 2 );